import{_ as e}from"./index-f506a943.js";const r={};function c(n,t){return null}const s=e(r,[["render",c]]);export{s as default};
