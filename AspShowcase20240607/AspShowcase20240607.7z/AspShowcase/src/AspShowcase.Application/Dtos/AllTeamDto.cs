﻿using System;

namespace AspShowcase.Application.Dtos
{
    public record AllTeamDto(Guid Guid, string Name, string Schoolclass);
}
